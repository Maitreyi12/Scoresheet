// Java Program to reverse a given number using Recursive function

// Refer C/Exp_02
// LMS compiler required C code
