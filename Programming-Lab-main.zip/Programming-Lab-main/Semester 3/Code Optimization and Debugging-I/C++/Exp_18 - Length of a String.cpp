//  C++ Program to Find the Length of a String.

// To compute the length (size) of a string

#include <iostream>
#include <cstring>
using std::cout;

int main() {
    cout << "String Length = " << strlen("C++ Programming");

    return 0;
}

/* Output: String Length = 15
*/