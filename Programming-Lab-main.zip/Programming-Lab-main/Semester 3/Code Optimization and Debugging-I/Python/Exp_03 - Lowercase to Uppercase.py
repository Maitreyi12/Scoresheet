#  Python Program to convert lowercase string to uppercase string

# Get the input string
# Convert lower case to upper case 
# Print the output

print(input().upper())

# Input: sathyabama
# Output: SATHYABAMA

